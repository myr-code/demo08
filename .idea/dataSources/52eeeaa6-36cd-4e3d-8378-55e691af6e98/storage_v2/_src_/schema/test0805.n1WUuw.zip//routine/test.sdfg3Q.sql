create
    definer = root@localhost procedure test(IN types int)
BEGIN
	#Routine body goes here...
	drop table if exists ls;
CREATE TEMPORARY TABLE ls(id int,name VARCHAR(50),type int);

INSERT INTO ls
SELECT id,name,types FROM t_user;
	select * from ls;


END;

